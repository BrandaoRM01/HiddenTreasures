from flask import Blueprint, request
from projeto.controllers import PontoTuristicoController

pontos_bp = Blueprint('pontos', __name__)

controller = PontoTuristicoController()

@pontos_bp.route('/')
def index():
    return controller.preparar_index()

@pontos_bp.route('/erro')
def erro():
    return controller.preparar_erro()

@pontos_bp.route('/sobre')
def sobre():
    return controller.preparar_sobre()

@pontos_bp.route('/pontos')
def pontos():
    return controller.preparar_pontos_turisticos()

@pontos_bp.route('/detalhes-ponto/<int:id>')
def detalhes_ponto(id):
    return controller.preparar_detalhes_ponto()

@pontos_bp.route('/buscar-pontos', methods=['POST'])
def buscar_pontos():
    return controller.listar_pontos_busca()

@pontos_bp.route('/admin/gerenciar-pontos')
def gerenciar_pontos():
    return controller.preparar_gerenciar_pontos()

@pontos_bp.route('/admin/gerenciar-sugestoes')
def gerenciar_sugestoes():
    return controller.preparar_gerenciar_sugestoes()

@pontos_bp.route('/sugerir-ponto')
def sugerir_ponto():
    return controller.preparar_sugerir_ponto()

@pontos_bp.route('/admin/editar-ponto/<int:id>')
def editar_ponto_pagina(id):
    return controller.preparar_editar_ponto(id)

@pontos_bp.route('/editar-sugestao/<int:id>')
def editar_sugestao_pagina(id):
    return controller.preparar_editar_sugestao(id)

@pontos_bp.route('/api/pontos', methods=['GET', 'POST'])
def api_pontos():
    if request.method == 'POST':
        return controller.cadastrar_ponto()
    return controller.listar_pontos()

@pontos_bp.route('/api/pontos/<int:id>', methods=['GET', 'PUT', 'DELETE'])
def api_pontos_param(id):
    if request.method == 'PUT':
        return controller.editar_ponto(id)
    elif request.method == 'DELETE':
        return controller.remover_ponto(id)
    return controller.buscar_ponto(id)

@pontos_bp.route('/api/pontos/sugestoes', methods=['GET'])
def api_pontos_sugestoes():
    return controller.listar_sugestoes()

@pontos_bp.route('/api/pontos/minhas-sugestoes', methods=['GET'])
def api_minhas_sugestoes():
    return controller.listar_sugestoes_usuario()

@pontos_bp.route('/api/pontos/index', methods=['GET'])
def api_pontos_index():
    return controller.listar_index()

@pontos_bp.route('/api/pontos/detalhes/<int:id>')
def api_detalhes_ponto(id):
    return controller.detalhes_ponto_api(id)